/*
 * NombreProgra.c
 *
 * Created: 
 * Author: 
 * Description: 
 */
/****************************************/
// Encabezado (Libraries)

#define F_CPU 16000000

#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>

#include "Ale-lib-SPI.h"
#include "Ale-lib-UART.h"

volatile uint8_t contador = 0;

uint8_t UART_recByte(); 




/****************************************/
// Function prototypes

void setup();
void print_contador_master(uint8_t counter); 
char UART_ReChar(void);




/****************************************/
// Main Function

int main(void)
{
	
	setup();
	/* Replace with your application code */
	
	
	
	while (1)
	{
		
		
		
	}
}

/****************************************/
// NON-Interrupt subroutines


void setup(){
	
	cli();
	
	//Inicializacion de SPI
	SPI_init(SLAVE_SS, DATA_ORDER_MSB, CLK_LOW, CLK_FIRST_EDGE); 
	SPCR |= (1 << SPIE); // Habilitar interrupciones
	
	
	//Inicializacion de pines de salida
	
	DDRD |= (1 << PORTD2)|(1 << PORTD3)|(1 << PORTD4)|(1 << PORTD5)|(1 << PORTD6)|(1 << PORTD7);
	DDRC |= (1 << PORTC0)|(1 << PORTC1);
	
	UART_init();
	
	
	sei();
	
}


void print_contador_master(uint8_t counter){
	
	/*
	MASTER PINOUT

	ESCLAVO PINOUT

	LSB

	PD2
	PD3
	PD4
	PD5
	PD6
	PD7
	PC0
	PC1

	MSB
	*/
	
	
	if (counter & 0b00000001)
	{
		PORTD |= (1 << PORTD2);
	} else {
		
		PORTD &= ~(1 << PORTD2);
	}
	
	if (counter & 0b00000010)
	{
		PORTD |= (1 << PORTD3);
		} else {
		
		PORTD &= ~(1 << PORTD3);
	}
	
	if (counter & 0b00000100)
	{
		PORTD |= (1 << PORTD4);
		} else {
		
		PORTD &= ~(1 << PORTD4);
	}
	
	if (counter & 0b00001000)
	{
		PORTD |= (1 << PORTD5);
		} else {
		
		PORTD &= ~(1 << PORTD5);
	}
	
	if (counter & 0b00010000)
	{
		PORTD |= (1 << PORTD6);
		} else {
		
		PORTD &= ~(1 << PORTD6);
	}
	
	if (counter & 0b00100000)
	{
		PORTD |= (1 << PORTD7);
		} else {
		
		PORTD &= ~(1 << PORTD7);
	}
	
	if (counter & 0b01000000)
	{
		PORTC |= (1 << PORTC0);
		} else {
		
		PORTC &= ~(1 << PORTC0);
	}
	
	if (counter & 0b10000000)
	{
		PORTC |= (1 << PORTC1);
		} else {
		
		PORTC &= ~(1 << PORTC1);
	}
	
	
	
}




/****************************************/
// Interrupt routines



ISR(SPI_STC_vect) {
	// Rutina de interrupci�n por transferencia SPI completa
	contador = SPDR; // Lee el byte recibido
	print_contador_master(contador); // Actualiza el contador f�sico
	
}